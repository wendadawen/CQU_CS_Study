CREATE TABLE `user`  (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户名',
  `password` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '密码',
  `email` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '邮箱',
  `qq_openid` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'QQ登录标识符',
  `wx_openid` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '微信登录标识符',
  `real_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '真实姓名',
  `age` int(11) NULL DEFAULT NULL COMMENT '年龄',
  `phone` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '手机号',
  `gender` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '性别 1:男 0:女',
  `desc` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '简介',
  `register_time` datetime  NULL DEFAULT NULL COMMENT '注册时间',
  `login_time` datetime  NULL DEFAULT NULL COMMENT '上次登录时间',
  `pic` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '头像',
  `look` int(11) NULL DEFAULT NULL COMMENT '查看数',
  `is_secret` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '是否私密 0：私密 1：公开',
  `dept_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '部门名称',
  `dept_id` int(11) NULL DEFAULT NULL COMMENT '部门id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 22 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, 'admin', 'admin', 'zijun1024@aliyun.com', NULL, NULL, '5', 20, '110', NULL, NULL, '2019-12-01 10:51:50', '2020-01-03 00:00:00', 'http://localhost:8080/upload/def.png', 48, NULL, '', 5);
INSERT INTO `user` VALUES (2, 'xiaodong', 'admin', 'xiaobiao@dfbz.com', NULL, NULL, '小东', 18, '110', '1', '我很帅啊', '2019-12-02 12:35:10', '2019-11-20 10:51:53', 'http://localhost:8080/upload/def.png', 32, '1', '研发部', 1);
INSERT INTO `user` VALUES (3, 'xiaofang', 'admin', 'xiaofang@dfbz.com', NULL, NULL, '小方', 18, '110', '1', '我很帅啊', '2019-12-02 12:35:10', '2019-11-20 10:51:53', 'http://localhost:8080/upload/def.png', 29, '1', '研发部', 1);
INSERT INTO `user` VALUES (4, 'xiaobiao', 'admin', 'xiaobiao@dfbz.com', NULL, NULL, '小标', 18, '110', '1', '我很帅啊', '2019-12-02 12:35:10', '2019-11-20 10:51:53', 'http://localhost:8080/upload/def.png', 27, '1', '研发部', 1);
INSERT INTO `user` VALUES (5, 'xiaozhun', 'admin', 'xiaozhun@dfbz.com', NULL, NULL, '小准', 18, '110', '1', '我很帅啊', '2019-12-02 12:35:10', '2019-11-20 10:51:53', 'http://localhost:8080/upload/def.png', 31, '1', '研发部', 1);
INSERT INTO `user` VALUES (6, 'dfbz', 'admin', 'dfbz@dfbz.com', NULL, NULL, '东方标准', 18, '110', '1', '我很帅啊', '2019-11-28 11:30:24', '2019-11-20 10:51:53', 'http://localhost:8080/upload/def.png', 20, '1', '研发部', 1);
INSERT INTO `user` VALUES (7, 'xiaoming', 'admin', 'xm@dfbz.com', NULL, NULL, '小明', 18, '110', '1', '我很帅啊', '2019-12-04 07:30:28', '2019-11-20 10:51:53', 'http://localhost:8080/upload/def.png', 21, '1', '研发部', 1);
INSERT INTO `user` VALUES (8, 'root', 'admin', 'root@dfbz.com', NULL, NULL, '管理员', 28, '110', '0', NULL, '2019-12-06 12:33:41', '2019-12-06 00:00:00', 'http://localhost:8080/upload/22892836-ed70-4039-8558-69dc81dd676b.png', 3, '0', '', 3);
INSERT INTO `user` VALUES (9, 'root_1', 'admin', 'root_1@dfbz.com', NULL, NULL, '管理员1号', 18, '119', '0', NULL, '2019-12-06 12:37:29', '2019-12-06 00:00:00', 'http://localhost:8080/upload/def.png', 0, '0', NULL, NULL);
INSERT INTO `user` VALUES (17, 'cc-475fd36f42ef', NULL, NULL, '3584F8F99BE67A5254A122D123B2BE24', NULL, 'Cool', 3332, '111', NULL, NULL, '2019-12-27 12:07:54', '2019-12-27 00:00:00', 'http://localhost:8080/upload/f1a3139d-d51a-4376-9ad7-90a4f2aa28de.png', 2, NULL, '秘书部', 7);
INSERT INTO `user` VALUES (18, 'af-845c0bfa13d5', NULL, NULL, '80303D26E1091C58F41FFAB08123F427', NULL, 'qq', 11, '110', NULL, NULL, '2019-12-27 15:30:53', '2020-01-03 00:00:00', 'http://thirdqq.qlogo.cn/g?b=oidb&k=7ywAfU4U8EOKpibrQ2UXibkw&s=100&t=1556885708', 2, NULL, '', 4);
INSERT INTO `user` VALUES (19, 'a9-4b9ef510e8a9', NULL, NULL, NULL, 'oQ4QeuPW7WL6ZwKt4Dc9wlc8WjRY', 'For', NULL, NULL, '1', NULL, '2019-12-31 10:49:37', '2020-01-03 00:00:00', 'http://thirdwx.qlogo.cn/mmopen/vi_32/icxlG7XRNqvQ4gUhgicXlz0oH4icR2E2MH8T0qic2X2KdbIiaKGlp9FQ91qnHjr2KW2uBBOZyfia7WOasvgIjgh3yK4A/132', 0, '0', NULL, NULL);
INSERT INTO `user` VALUES (20, '7f-3ea444301d8d', NULL, NULL, '01CC173B24CFE00ABD613E6AB58CED54', NULL, '嘿嘿嘿', NULL, NULL, NULL, NULL, '2019-12-31 16:45:47', '2019-12-31 00:00:00', 'http://thirdqq.qlogo.cn/g?b=oidb&k=IMauKBZYyia9kUL43DEiaMOQ&s=100&t=1557174653', 0, '0', NULL, NULL);
INSERT INTO `user` VALUES (21, '8a-6e107a887a55', NULL, NULL, NULL, 'oQ4QeuNRR9S_4IyRzkJbNRoPNSH4', '嘿嘿嘿', 1, '234234234', NULL, NULL, '2019-12-31 16:46:20', '2019-12-31 00:00:00', 'http://localhost:8080/upload/a3fb2503-b1b1-46e1-854a-8051c7368b41.jpg', 1, '1', '财务部', 4);
function ux = DKIniU(x)
format long;
ux = x*x;
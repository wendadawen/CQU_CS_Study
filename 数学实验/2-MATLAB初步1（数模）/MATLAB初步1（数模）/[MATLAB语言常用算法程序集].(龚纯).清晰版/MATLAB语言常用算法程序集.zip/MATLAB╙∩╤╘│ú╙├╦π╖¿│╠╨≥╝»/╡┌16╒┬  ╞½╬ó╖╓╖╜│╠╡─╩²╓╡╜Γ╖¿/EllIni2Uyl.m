function uxy = EllIni2Uyl(x,y)
format long;
uxy = 0;